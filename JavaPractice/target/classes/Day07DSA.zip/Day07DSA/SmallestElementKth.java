package Day07DSA;

public class SmallestElementKth {
	public static void findSecondSmallestNum(int []array,int k) {
		int first=array[0];
		int second=0;
		for(int i=0;i<array.length;i++) {
			if(array[i]<first) {
				second=first;
				first=array[i];
			}
			if(array[i]!=first) {
				if(array[i]<second) {
					second=array[i];
				}
			}
			}
		System.out.println("k�th smallest array element is "+second);
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []array={7, 4, 6, 3, 9, 1};
				int k = 2;
				findSecondSmallestNum(array,k);

	}

}
