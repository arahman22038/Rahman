package Day6DSA;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int ar[]=new int[5];
for(int i : ar)
{
	System.out.print(i);
}
System.out.println("===================================");
ar=new int[10];
for(int i : ar)
{
	System.out.print(i);
}
	}

}
