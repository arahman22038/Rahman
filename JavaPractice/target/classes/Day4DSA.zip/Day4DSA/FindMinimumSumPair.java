package Day4DSA;

public class FindMinimumSumPair {

	public static void main(String[] args) {
	

	}

}
